/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package br.com.bean;

import br.com.controle.Categoria;
import br.com.modelo.CategoriasDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author Thali
 */

@WebServlet(name = "ServletEditarCategoria", urlPatterns = {"/ServletEditarCategoria"})
public class ServletEditarCategoria extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int codigo = Integer.parseInt(request.getParameter("codigo"));
        String nomeCategoria = request.getParameter("nome");

        Categoria categoria = new Categoria();
        categoria.setCodigo(codigo);
        categoria.setNome(nomeCategoria);

        CategoriasDAO categoriasDAO = new CategoriasDAO();
        categoriasDAO.alterar(categoria);

        request.getRequestDispatcher("categorias.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
