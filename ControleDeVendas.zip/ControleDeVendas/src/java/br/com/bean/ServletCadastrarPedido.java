package br.com.bean;

import br.com.controle.Cliente;
import br.com.controle.Pedido;
import br.com.controle.Produto;
import br.com.controle.ProdutoPedido;
import br.com.modelo.PedidosDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thali
 */


@WebServlet(name = "ServletCadastrarPedido", urlPatterns = {"/ServletCadastrarPedido"})
public class ServletCadastrarPedido extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int clienteId = Integer.parseInt(request.getParameter("cliente_id"));
        String dataCompra = request.getParameter("data_compra");
        double total = Double.parseDouble(request.getParameter("total"));

        Cliente cliente = new Cliente();
        cliente.setId(clienteId);

        Pedido pedido = new Pedido();
        pedido.setCliente(cliente);
        pedido.setDataCompra(dataCompra);
        pedido.setTotal(total);

        PedidosDAO pedidosDAO = new PedidosDAO();
        pedidosDAO.inserir(pedido);

        response.sendRedirect("pedidos.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
