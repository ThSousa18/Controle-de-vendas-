package br.com.bean;

import br.com.modelo.PedidosDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author Thali
 */

@WebServlet(name = "ServletDeletarPedido", urlPatterns = {"/ServletDeletarPedido"})
public class ServletDeletarPedido extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        PedidosDAO pedidosDAO = new PedidosDAO();
        pedidosDAO.deletar(id);

        response.sendRedirect("pedidos.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
