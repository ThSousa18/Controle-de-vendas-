package br.com.bean;

import br.com.controle.Cliente;
import br.com.controle.Pedido;
import br.com.controle.Produto;
import br.com.controle.ProdutoPedido;
import br.com.modelo.PedidosDAO;
import java.io.IOException;
import java.util.ArrayList;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author Thali
 */

@WebServlet(name = "ServletEditarPedido", urlPatterns = {"/ServletEditarPedido"})

public class ServletEditarPedido extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        int clienteId = Integer.parseInt(request.getParameter("cliente_id"));
        String dataCompra = request.getParameter("data_compra");
        double total = Double.parseDouble(request.getParameter("total"));

        Cliente cliente = new Cliente();
        cliente.setId(clienteId);

        Pedido pedido = new Pedido();
        pedido.setId(id);
        pedido.setCliente(cliente);
        pedido.setDataCompra(dataCompra);
        pedido.setTotal(total);

        PedidosDAO pedidosDAO = new PedidosDAO();
        pedidosDAO.editar(pedido);

        response.sendRedirect("pedidos.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
