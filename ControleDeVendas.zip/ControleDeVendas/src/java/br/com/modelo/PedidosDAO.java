/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

import br.com.controle.Pedido;
import br.com.controle.Cliente;
import br.com.controle.Produto;
import br.com.controle.ProdutoPedido;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Thali
 */



public class PedidosDAO extends DAO {

    public void inserir(Pedido pedido) {
        try {
            abrirBanco();
            String query = "INSERT INTO pedidos (cliente_id, data_compra, total) VALUES (?, ?, ?)";
            pst = con.prepareStatement(query);
            pst.setInt(1, pedido.getCliente().getId());
            pst.setString(2, pedido.getDataCompra());
            pst.setDouble(3, pedido.getTotal());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao inserir pedido: " + e.getMessage());
        }
    }

    public ArrayList<Pedido> listarPedidos() {
        ArrayList<Pedido> listaPedidos = new ArrayList<>();
        try {
            abrirBanco();
            String query = "SELECT pedidos.id, clientes.nome, pedidos.data_compra, pedidos.total " +
                           "FROM pedidos JOIN clientes ON pedidos.cliente_id = clientes.id";
            pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Pedido pedido = new Pedido();
                Cliente cliente = new Cliente();
                cliente.setNome(rs.getString("nome"));

                pedido.setId(rs.getInt("id"));
                pedido.setCliente(cliente);
                pedido.setDataCompra(rs.getString("data_compra"));
                pedido.setTotal(rs.getDouble("total"));


                ArrayList<ProdutoPedido> produtos = new ArrayList<>();
                String queryProdutos = "SELECT produtos.nome, pedidos_produtos.quantidade " +
                                       "FROM pedidos_produtos JOIN produtos ON pedidos_produtos.produto_id = produtos.id " +
                                       "WHERE pedidos_produtos.pedido_id = ?";
                pst = con.prepareStatement(queryProdutos);
                pst.setInt(1, pedido.getId());
                ResultSet rsProdutos = pst.executeQuery();
                while (rsProdutos.next()) {
                    Produto produto = new Produto();
                    produto.setNome(rsProdutos.getString("nome"));

                    ProdutoPedido produtoPedido = new ProdutoPedido();
                    produtoPedido.setProduto(produto);
                    produtoPedido.setQuantidade(rsProdutos.getInt("quantidade"));

                    produtos.add(produtoPedido);
                }
                pedido.setProdutos(produtos);

                listaPedidos.add(pedido);
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao listar pedidos: " + e.getMessage());
        }
        return listaPedidos;
    }

    public void editar(Pedido pedido) {
        try {
            abrirBanco();
            String query = "UPDATE pedidos SET cliente_id = ?, data_compra = ?, total = ? WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, pedido.getCliente().getId());
            pst.setString(2, pedido.getDataCompra());
            pst.setDouble(3, pedido.getTotal());
            pst.setInt(4, pedido.getId());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao editar pedido: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        try {
            abrirBanco();
            String query = "DELETE FROM pedidos WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, id);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao deletar pedido: " + e.getMessage());
        }
    }
}
