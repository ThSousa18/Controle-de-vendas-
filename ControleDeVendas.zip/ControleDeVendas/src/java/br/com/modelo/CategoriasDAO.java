/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Thali
 */

import br.com.controle.Categoria;
import br.com.controle.Categoria;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CategoriasDAO extends DAO {

    public void inserir(Categoria categoria) {
    try {
        abrirBanco();
        String query = "INSERT INTO categorias(nome) VALUES(?)";
        pst = con.prepareStatement(query);
        pst.setString(1, categoria.getNome());
        
        System.out.println("Inserindo categoria: " + categoria.getNome()); 
        
        pst.execute();
        fecharBanco();
    } catch (Exception e) {
        System.out.println("Erro ao inserir categoria: " + e.getMessage());
    }
}


    public ArrayList<Categoria> pesquisarTudo() {
        ArrayList<Categoria> listaCategorias = new ArrayList<>();
        try {
            abrirBanco();
            String query = "SELECT id, nome FROM categorias ORDER BY id DESC";
            pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Categoria categoria = new Categoria();
                categoria.setCodigo(rs.getInt("id"));
                categoria.setNome(rs.getString("nome"));
                listaCategorias.add(categoria);
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
        return listaCategorias;
    }

    public void deletar(Categoria categoria) {
        try {
            abrirBanco();
            String query = "DELETE FROM categorias WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, categoria.getCodigo());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }

    public void alterar(Categoria categoria) {
        try {
            abrirBanco();
            String query = "UPDATE categorias SET nome = ? WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, categoria.getNome());
            pst.setInt(2, categoria.getCodigo());
            pst.executeUpdate();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }

    public Categoria pesquisar(int id) {
        try {
            abrirBanco();
            String query = "SELECT id, nome FROM categorias WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Categoria categoria = new Categoria();
                categoria.setCodigo(rs.getInt("id"));
                categoria.setNome(rs.getString("nome"));
                return categoria;
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
        return null;
    }
}
