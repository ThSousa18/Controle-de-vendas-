/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Thali
 */

import br.com.controle.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ClientesDAO extends DAO {

    public void inserir(Cliente cliente) {
        try {
            abrirBanco();
            String query = "INSERT INTO clientes (nome, telefone) VALUES (?, ?)";
            pst = con.prepareStatement(query);
            pst.setString(1, cliente.getNome());
            pst.setString(2, cliente.getTelefone());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao inserir cliente: " + e.getMessage());
        }
    }

    public ArrayList<Cliente> pesquisarTudo() {
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        try {
            abrirBanco();
            String query = "SELECT id, nome, telefone FROM clientes";
            pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setTelefone(rs.getString("telefone"));
                listaClientes.add(cliente);
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao listar clientes: " + e.getMessage());
        }
        return listaClientes;
    }

    public void editar(Cliente cliente) {
        try {
            abrirBanco();
            String query = "UPDATE clientes SET nome = ?, telefone = ? WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, cliente.getNome());
            pst.setString(2, cliente.getTelefone());
            pst.setInt(3, cliente.getId());
            pst.executeUpdate();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao editar cliente: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        try {
            abrirBanco();
            String query = "DELETE FROM clientes WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, id);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao deletar cliente: " + e.getMessage());
        }
    }
}
