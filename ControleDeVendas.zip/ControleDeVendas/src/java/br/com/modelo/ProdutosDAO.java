/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

import br.com.controle.Produto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Thali
 */

public class ProdutosDAO extends DAO {

    public void inserir(Produto produto) {
        try {
            abrirBanco();
            String query = "INSERT INTO produtos (nome, descricao, preco, estoque, categoria_id) VALUES (?, ?, ?, ?, (SELECT id FROM categorias WHERE nome = ?))";
            pst = con.prepareStatement(query);
            pst.setString(1, produto.getNome());
            pst.setString(2, produto.getDescricao());
            pst.setDouble(3, produto.getPreco());
            pst.setInt(4, produto.getEstoque());
            pst.setString(5, produto.getCategoriaNome());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao inserir produto: " + e.getMessage());
        }
    }

    public ArrayList<Produto> pesquisarTudo() {
        ArrayList<Produto> listaProdutos = new ArrayList<>();
        try {
            abrirBanco();
            String query = "SELECT produtos.id, produtos.nome, produtos.descricao, produtos.preco, produtos.estoque, categorias.nome AS categoria FROM produtos JOIN categorias ON produtos.categoria_id = categorias.id";
            pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setEstoque(rs.getInt("estoque"));
                produto.setCategoriaNome(rs.getString("categoria"));
                listaProdutos.add(produto);
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao listar produtos: " + e.getMessage());
        }
        return listaProdutos;
    }

    public void editar(Produto produto) {
        try {
            abrirBanco();
            String query = "UPDATE produtos SET nome = ?, descricao = ?, preco = ?, estoque = ?, categoria_id = (SELECT id FROM categorias WHERE nome = ?) WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, produto.getNome());
            pst.setString(2, produto.getDescricao());
            pst.setDouble(3, produto.getPreco());
            pst.setInt(4, produto.getEstoque());
            pst.setString(5, produto.getCategoriaNome());
            pst.setInt(6, produto.getId());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao editar produto: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        try {
            abrirBanco();
            String query = "DELETE FROM produtos WHERE id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, id);
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro ao deletar produto: " + e.getMessage());
        }
    }
}
